<!--Jquery-->
<script src="assets/js/jquery-3.5.0.min.js"></script>
<!--Bootstrap Js-->
<script src="assets/js/bootstrap.bundle.min.js"></script>
<!--Feather Icon-->
<script src="assets/css/icons/feather.min.js"></script>
<script src="assets/js/owl.carousel.min.js"></script>
<script src="assets/js/jquery.ddslick.min.js"></script>
<script src="assets/js/countrySelect.min.js"></script>
<!--sidebar sticky Icon-->
<script src="assets/js/rAF.js"></script>
<script src="assets/js/ResizeSensor.js"></script>
<script src="assets/js/sticky-sidebar.js"></script>
<!--Main Js-->
<script src="assets/js/main.js"></script>
<!-- Custom JS -->
<script src="assets/js/custom.js"></script>

</body>

</html>